package com.emp.model;

public class Address_detailModel {

	private int id;
	
	private String country;
	
	private String state;
	
	private String city;
	
	private String district;
	
	private String pincode;
	
	private String temp_address;
	
	private String permn_address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getTemp_address() {
		return temp_address;
	}

	public void setTemp_address(String temp_address) {
		this.temp_address = temp_address;
	}

	public String getPermn_address() {
		return permn_address;
	}

	public void setPermn_address(String permn_address) {
		this.permn_address = permn_address;
	}
	
	
	
}
