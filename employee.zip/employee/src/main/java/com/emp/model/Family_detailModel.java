package com.emp.model;

public class Family_detailModel {
	
private int id;
	
	private String father_first_name;
	
	private String father_middle_name;
	
	private String father_last_name;
	
	private String contact_no;
	
	private String occupation;
	
	private String mother_first_name;
	
	private String mother_last_name;
	
	private String children_first_name;
	
	private String children_last_name;
	
	private String spouse_first_name;
	
	private String spouse_last_name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFather_first_name() {
		return father_first_name;
	}

	public void setFather_first_name(String father_first_name) {
		this.father_first_name = father_first_name;
	}

	public String getFather_middle_name() {
		return father_middle_name;
	}

	public void setFather_middle_name(String father_middle_name) {
		this.father_middle_name = father_middle_name;
	}

	public String getFather_last_name() {
		return father_last_name;
	}

	public void setFather_last_name(String father_last_name) {
		this.father_last_name = father_last_name;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getMother_first_name() {
		return mother_first_name;
	}

	public void setMother_first_name(String mother_first_name) {
		this.mother_first_name = mother_first_name;
	}

	public String getMother_last_name() {
		return mother_last_name;
	}

	public void setMother_last_name(String mother_last_name) {
		this.mother_last_name = mother_last_name;
	}

	public String getChildren_first_name() {
		return children_first_name;
	}

	public void setChildren_first_name(String children_first_name) {
		this.children_first_name = children_first_name;
	}

	public String getChildren_last_name() {
		return children_last_name;
	}

	public void setChildren_last_name(String children_last_name) {
		this.children_last_name = children_last_name;
	}

	public String getSpouse_first_name() {
		return spouse_first_name;
	}

	public void setSpouse_first_name(String spouse_first_name) {
		this.spouse_first_name = spouse_first_name;
	}

	public String getSpouse_last_name() {
		return spouse_last_name;
	}

	public void setSpouse_last_name(String spouse_last_name) {
		this.spouse_last_name = spouse_last_name;
	}


	
}
