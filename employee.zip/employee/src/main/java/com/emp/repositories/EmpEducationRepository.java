package com.emp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.emp.entity.EmpEducation;
@Repository
public interface  EmpEducationRepository extends JpaRepository<EmpEducation, Integer>{
	
	
}

	




	



	


