package com.emp.repositories;
/*
package com.emp.entity.repositories;
import java.util.List;
import java.util.Optional;

 import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
 import org.springframework.data.jpa.repository.JpaRepository; 

import org.springframework.data.jpa.repository.Query; 
import org.springframework.stereotype.Repository;

public class EmpRepo {

	
	 *
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @Repository public interface EmpRepo extends JpaRepository<Employee, String>
	 * {
	 * 
	 * @Query(value ="SELECT * from login1 WHERE usernam e = name ", nativeQuery =
	 * true) public Optional<User> findByUserName(String name);
	 * 
	 * public List<Employee> findAll();
	 * 
	 * 
	 * 
	 * //public static void delete(employee emp) { // TODO Auto-generated method
	 * stub
	 * 
	 * //}
	 * 
	 * 
	 * 
	 * }
	 
}
*/
